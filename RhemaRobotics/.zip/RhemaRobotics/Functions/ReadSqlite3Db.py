#!/usr/bin/env python3
import os
import sys
sys.path.append('/home/pi/ArmPi/HiwonderSDK/')
import time
import sqlite3 as sql

print('''
**********************************************************
*********功能:幻尔科技树莓派扩展板，动作组控制例程********
**********************************************************
----------------------------------------------------------
Official website:http://www.lobot-robot.com/pc/index/index
Online mall:https://lobot-zone.taobao.com/
----------------------------------------------------------
以下指令均需在LX终端使用，LX终端可通过ctrl+alt+t打开，或点
击上栏的黑色LX终端图标。
----------------------------------------------------------
Usage:
    sudo python3 ActionGroupControlDemo.py
----------------------------------------------------------
Version: --V1.0  2020/08/12
----------------------------------------------------------
Tips:
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！
----------------------------------------------------------
''')

def readAction(actNum):
    '''
    运行动作组，无法发送stop停止信号
    :param actNum: 动作组名字 ， 字符串类型
    :param times:  运行次数
    :return:
    '''
    if actNum is None:
        return
    actNum = "/home/pi/Desktop/ArmPi/ActionGroups/" + actNum + ".d6a"
    
    if os.path.exists(actNum) is True:
        ag = sql.connect(actNum)
        cu = ag.cursor()
        cu.execute("select * from ActionGroup")
        while True:
            act = cu.fetchone()
            if act is not None:
                for i in range(0, len(act), 1):
                    print(act[i]) 
                else:   # 运行完才退出
                    break
        cu.close()
        ag.close()
    else:
        print("未能找到动作组文件")

# 动作组需要保存在路径/home/pi/ArmPi/ActionGroups下
readAction('2')
