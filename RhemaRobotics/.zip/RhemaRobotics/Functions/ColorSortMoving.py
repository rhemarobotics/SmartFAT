'''
-------------------------------------------------
sudo python3 ColorSortMoving.py
-------------------------------------------------
'''

#!/usr/bin/python3
# coding=utf8

import sys
sys.path.append('/home/pi/RhemaRobotics/')
import cv2
import time
import threading
import HiwonderSDK.Board as Board
from Package import opencvfunc, Camera
from ArmIK.Transform import *
from ArmIK.ArmMoveIK import *
from CameraCalibration.CalibrationConfig import *
from Package.LABConfig import *

if sys.version_info.major == 2:
    print('Please run this program with python3!')
    sys.exit(0)

# Set robot invk.
AK = ArmIK()

# Set gripper close angle.
servo1 = 500

# Set color for detection.
__target_color = ()

# Robot Init. Position.
def initMove():
    Board.setBusServoPulse(1, servo1 - 50, 300)
    Board.setBusServoPulse(2, 500, 500)
    AK.setPitchRangeMoving((0, 10, 10), -30, -30, -90, 2000)

# Global variables.
__isRunning = False
_stop = False
get_roi = False
detect_color = 'None'
start_pick_up = False
start_count_t1 = True

# State machine.
def reset():
    global __target_color
    global _stop
    global count
    global get_roi
    global color_list
    global detect_color
    global start_pick_up
    global start_count_t1

    __target_color = ()
    _stop = False
    count = 0
    get_roi = False
    color_list = []
    detect_color = 'None'
    start_pick_up = False
    start_count_t1 = True

def init():
    print("ColorSorting Init")
    initMove()

def start():
    global __isRunning
    reset()
    __isRunning = True
    print("ColorSorting Start")

def stop():
    global _stop
    global __isRunning
    _stop = True
    __isRunning = False
    print("ColorSorting Stop")

def exit():
    global _stop
    global __isRunning
    _stop = True
    __isRunning = False
    print("ColorSorting Exit")

# Global variables for robot motion.
rotation_angle = 0
world_X, world_Y = 0, 0
last_x, last_y = 0, 0

def move():
    global _stop
    global get_roi
    global __isRunning
    global detect_color
    global start_pick_up
    global rotation_angle
    global world_X, world_Y

    unreachable = False 

    # Place coordinate for color squares.
    coordinate = {
        'red':   (15 + 0.5, 6 - 0.5, 1.5),
        'green': (15 + 0.5, 6 - 0.5, 1.5),
        'blue':  (15 + 0.5, 6 - 0.5, 1.5),
    }
    
    while True:
        if __isRunning:        
            if detect_color != 'None' and start_pick_up:  #如果检测到方块没有移动一段时间后，开始夹取
                #移到目标位置，高度7cm, 通过返回的结果判断是否能到达指定位置
                #如果不给出运行时间参数，则自动计算，并通过结果返回
                Board.setboardRGB(detect_color)
                #Board.setBuzzerTimer(0.1)
                result = AK.setPitchRangeMoving((world_X, world_Y, 7), -90, -90, 0)  
                if result == False:
                    unreachable = True
                    print('target is unreachable...')
                else:
                    unreachable = False
                    time.sleep(result[2]/1000) #如果可以到达指定位置，则获取运行时间
                    
                    # open gripper and turn to the correct pitch.
                    if not __isRunning:
                        continue
                    servo2_angle = getAngle(world_X, world_Y, rotation_angle) #计算夹持器需要旋转的角度
                    Board.setBusServoPulse(1, servo1 - 280, 500)  # 爪子张开
                    Board.setBusServoPulse(2, servo2_angle, 500)
                    time.sleep(0.5)
                    
                    # move to the target center position.
                    if not __isRunning:
                        continue
                    AK.setPitchRangeMoving((world_X, world_Y, 1.5), -90, -90, 0, 1000)
                    time.sleep(1.5)

                    # close the gipper.
                    if not __isRunning:
                        continue
                    Board.setBusServoPulse(1, servo1, 500)  #夹持器闭合
                    time.sleep(0.8)

                    # lift up the target.
                    if not __isRunning:
                        continue
                    Board.setBusServoPulse(2, 500, 500)
                    AK.setPitchRangeMoving((world_X, world_Y, 12), -90, -90, 0, 1000)  #机械臂抬起
                    time.sleep(1)

                    # move target to the place position.
                    if not __isRunning:
                        continue
                    result = AK.setPitchRangeMoving((coordinate[detect_color][0], coordinate[detect_color][1], 12), -90, -90, 0)   
                    time.sleep(result[2]/1000)
                    
                    # turn target to the correct pitch
                    if not __isRunning:
                        continue                   
                    servo2_angle = getAngle(coordinate[detect_color][0], coordinate[detect_color][1], -90)
                    Board.setBusServoPulse(2, servo2_angle, 500)
                    time.sleep(0.5)

                    # close to the place position.
                    if not __isRunning:
                        continue
                    AK.setPitchRangeMoving((coordinate[detect_color][0], coordinate[detect_color][1], coordinate[detect_color][2] + 3), -90, -90, 0, 500)
                    time.sleep(0.5)
                    
                    # more close to the place position.
                    if not __isRunning:
                        continue                    
                    AK.setPitchRangeMoving((coordinate[detect_color]), -90, -90, 0, 1000)
                    time.sleep(1)

                    # open the gripper.
                    if not __isRunning:
                        continue
                    Board.setBusServoPulse(1, servo1 - 200, 500)  # 爪子张开  ，放下物体
                    time.sleep(0.5)

                    # lift the gripper up.
                    if not __isRunning:
                        continue
                    AK.setPitchRangeMoving((coordinate[detect_color][0], coordinate[detect_color][1], 12), -90, -90, 0, 800)
                    time.sleep(0.8)

                    # move to the initial position.
                    initMove()  
                    time.sleep(1.5)
                    
                    #end moving.
                    get_roi = False
                    start_pick_up = False
                    detect_color = 'None'
                    Board.setboardRGB(detect_color)
        else:
            if _stop:
                _stop = False
                Board.setBusServoPulse(1, servo1 - 70, 300)
                time.sleep(0.5)
                Board.setBusServoPulse(2, 500, 500)
                AK.setPitchRangeMoving((0, 10, 10), -30, -30, -90, 1500)
                time.sleep(1.5)
            time.sleep(0.01)
          
# Run a task for robot pick and place motion.
th = threading.Thread(target=move)
th.setDaemon(True)
th.start()    

count = 0
center_list = []
t1 = 0
start_count_t1 = True

def run(img):
    global get_roi
    global __isRunning
    global start_pick_up
    global rotation_angle
    global last_x, last_y
    global world_X, world_Y
    global detect_color
    global count
    global center_list
    global start_count_t1, t1
        
    rect = None
    size = (640, 480)
    roi = ()

    # draw a cross line in the middle of frame.
    opencvfunc.drawCrossLine(img)
    if not __isRunning:
        return img
    # image processing.
    img_resize = cv2.resize(img.copy(), size, interpolation=cv2.INTER_NEAREST)
    img_gb = cv2.GaussianBlur(img_resize, (11, 11), 11)
    img_lab = cv2.cvtColor(img_gb, cv2.COLOR_BGR2LAB)
    # start pick up?
    if not start_pick_up:
        # find target color.
        imgcanny = opencvfunc.filterColour(img_lab, __target_color)
        # find its contour
        imgproc, rect = opencvfunc.getContours(imgcanny, img_resize, rect)
        # get Roi
        if not rect is None:
            box = np.int0(cv2.boxPoints(rect))
            roi = getROI(box)
            get_roi = True
            # get the center position of square.
            img_centerx, img_centery = getCenter(rect, roi, size, square_length)
            # convert the position to the robot.
            world_x, world_y = convertCoordinate(img_centerx, img_centery, size)
            # get square rotation.
            rotation_angle = round(rect[2],2)
            # draw center position and rotation via world.            
            cv2.putText(imgproc, '(' + str(world_x) + ',' + str(world_y) + ',' + str(rotation_angle) + ')', (min(box[0, 0], box[2, 0]), box[2, 1] - 10),
                cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, opencvfunc.range_rgb['green'], 1)
            # draw detected color.
            detect_color = __target_color
            cv2.putText(imgproc, "Color: " + detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1,
                opencvfunc.range_rgb["black"], 2)
            # if movement?
            distance = math.sqrt(pow(world_x - last_x, 2) + pow(world_y - last_y, 2))
            last_x, last_y = world_x, world_y
            # accumulator.
            if distance < 0.5:
                count += 1
                center_list.extend((world_x, world_y))
                if start_count_t1:
                    start_count_t1 = False
                    t1 = time.time()
                if time.time() - t1 > 1:
                    rotation_angle = rect[2] 
                    start_count_t1 = True
                    world_X, world_Y = np.mean(np.array(center_list).reshape(count, 2), axis=0)
                    center_list = []
                    count = 0
                    start_pick_up = True
            else:
                t1 = time.time()
                start_count_t1 = True
                center_list = []
                count = 0
        else:
            print('cannot find the target.')
    #return imgproc
    return img

# Demo and press 'ESC' to stop.
if __name__ == '__main__':
    init()
    start()
    __target_color = ('red')
    my_camera = Camera.Camera()
    my_camera.camera_open()
    #main loop
    while True:
        img = my_camera.frame
        if img is not None:
            frame = img.copy()
            Frame = run(frame)           
            cv2.imshow('Frame', Frame)
            key = cv2.waitKey(1)
            if key == 27:
                break
    #end loop
    my_camera.camera_close()
    cv2.destroyAllWindows()
