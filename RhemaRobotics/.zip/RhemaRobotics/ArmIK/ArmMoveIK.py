''' 具體操作步驟:
-------------------------------------------------------------
cd /home/pi/RhemaRobotics/ArmIK
sudo python3 ArmMoveIK.py
-------------------------------------------------------------
'''

#!/usr/bin/env python3
# encoding:utf-8

import sys
sys.path.append('/home/pi/RhemaRobotics/')
import time
import numpy as np
from math import sqrt
from ArmIK.InverseKinematics import *
from Sdk.Board import setBusServoPulse, getBusServoPulse

ik = IK('arm')

class ArmIK:
    # 把脈波寬度(ms)線性轉換到馬達旋轉角度角度(deg)
    servo3Range = (0, 1000, 0, 240) 
    servo4Range = (0, 1000, 0, 240)
    servo5Range = (0, 1000, 0, 240)
    servo6Range = (0, 1000, 0, 240)

    def __init__(self):
        self.setServoRange()

    def setServoRange(self, servo3_Range=servo3Range, servo4_Range=servo4Range, servo5_Range=servo5Range, servo6_Range=servo6Range):
        # map to different kind of servo.
        self.servo3Range = servo3_Range
        self.servo4Range = servo4_Range
        self.servo5Range = servo5_Range
        self.servo6Range = servo6_Range
        self.servo3Param = (self.servo3Range[1] - self.servo3Range[0]) / (self.servo3Range[3] - self.servo3Range[2])
        self.servo4Param = (self.servo4Range[1] - self.servo4Range[0]) / (self.servo4Range[3] - self.servo4Range[2])
        self.servo5Param = (self.servo5Range[1] - self.servo5Range[0]) / (self.servo5Range[3] - self.servo5Range[2])
        self.servo6Param = (self.servo6Range[1] - self.servo6Range[0]) / (self.servo6Range[3] - self.servo6Range[2])
    
    def transformAngelAdaptArm(self, theta3, theta4, theta5, theta6):
        # 把馬達旋轉角度(deg)轉換至相對應脈波位置(ms).
        servo3 = int((self.servo3Range[1] + self.servo3Range[0])/2 + round(theta3 * self.servo3Param))
        if servo3 > self.servo3Range[1] or servo3 < self.servo3Range[0] + 60: # 850ms < servo3(500ms) < 125ms
            logger.info('servo3(%s)over range(%s, %s)', servo3, self.servo3Range[0] + 60, self.servo3Range[1])
            return False

        servo4 = int((self.servo4Range[1] + self.servo4Range[0])/2 - round(theta4 * self.servo4Param))
        servo4 = servo4 -10 # offset
        if servo4 > self.servo4Range[1] or servo4 < self.servo4Range[0]: # 875ms < servo4(490ms) < 125ms
            logger.info('servo4(%s)over range(%s, %s)', servo4, self.servo4Range[0], self.servo4Range[1])
            return False

        servo5 = int(round((90.0-theta5) * self.servo5Param) + (self.servo5Range[1] + self.servo5Range[0])/2)
        servo5 = servo5 + 10 # offset
        if servo5 > ((self.servo5Range[1] + self.servo5Range[0])/2 + 90*self.servo5Param) or servo5 < ((self.servo5Range[1] + self.servo5Range[0])/2 - 90*self.servo5Param):
            logger.info('servo5(%s)over range(%s, %s)', servo5, self.servo5Range[0], self.servo5Range[1]) # 250ms < servo5(510ms) < 875ms
            return False
        
        if theta6 < -(self.servo6Range[3] - self.servo6Range[2])/2: # -120 deg.
            servo6 = int(round(((self.servo6Range[3] - self.servo6Range[2])/2 + (90 + (180 + theta6))) * self.servo6Param))
        else:
            servo6 = int(round(((self.servo6Range[3] - self.servo6Range[2])/2 - (90 - theta6)) * self.servo6Param))
        if servo6 > self.servo6Range[1] or servo6 < self.servo6Range[0]: # 0ms < servo6(500ms) < 1000ms
            logger.info('servo6(%s)over range(%s, %s)', servo6, self.servo6Range[0], self.servo6Range[1])
            return False

        return {"servo3": servo3, "servo4": servo4, "servo5": servo5, "servo6": servo6}

    def servosMove(self, servos, movetime=None):
        # 馬達轉至定位
        time.sleep(0.02)
        if movetime is None:
            max_d = 0
            for i in  range(0, 4):
                d = abs(getBusServoPulse(i + 3) - servos[i])
                if d > max_d:
                    max_d = d
            movetime = int(max_d*4)
        setBusServoPulse(3, servos[0], movetime)
        setBusServoPulse(4, servos[1], movetime)
        setBusServoPulse(5, servos[2], movetime)
        setBusServoPulse(6, servos[3], movetime)

        return movetime

    def setPitchRange(self, coordinate_data, alpha1, alpha2, da = 1):
        #設定手臂末端點座標位置(x,y,z cm)及俯仰角度範圍(alpha1，alpha2 deg.), 計算適合的解
        #無法求解則返回false
        x, y, z = coordinate_data
        if alpha1 >= alpha2:
            da = -da
        for alpha in np.arange(alpha1, alpha2, da):#da,每一次微動量
            result = ik.getRotationAngle((x, y, z), alpha)
            if result:
                theta3, theta4, theta5, theta6 = result['theta3'], result['theta4'], result['theta5'], result['theta6']
                servos = self.transformAngelAdaptArm(theta3, theta4, theta5, theta6)
                if servos != False:
                    return servos, alpha

        return False

    def setPitchRangeMoving(self, coordinate_data, alpha, alpha1, alpha2, movetime=None):
        #手臂末端點座標位置(cm) coordinate_data
        #手臂末端點俯仰角度(deg) alpha
        #俯仰角範圍(deg) alpha1, alpha2
        #如果無解返回false,否則返回馬達角度,俯仰角,運行時間(ms).
        x, y, z = coordinate_data
        result1 = self.setPitchRange((x, y, z), alpha, alpha1)
        result2 = self.setPitchRange((x, y, z), alpha, alpha2)
        if result1 != False:
            data = result1
            if result2 != False:
                if abs(result2[1] - alpha) < abs(result1[1] - alpha):
                    data = result2
        else:
            if result2 != False:
                data = result2
            else:
                return False
        servos, alpha = data[0], data[1]

        movetime = self.servosMove((servos["servo3"], servos["servo4"], servos["servo5"], servos["servo6"]), movetime)

        return servos, alpha, movetime


if __name__ == "__main__":
    AK = ArmIK()
    setBusServoPulse(1, 200, 500)
    setBusServoPulse(2, 500, 500)
    time.sleep(0.5)
    
    print(AK.setPitchRangeMoving((0, 15, 15), -30, -90, 0, 2000))
    time.sleep(2)
    print(AK.setPitchRangeMoving((15, 0, 15), -30, -90, 0, 2000))
    time.sleep(2)
    print(AK.setPitchRangeMoving((16.5, 0, 9.5), -30, -90, 0, 2000))
    time.sleep(2)    
    setBusServoPulse(1, 700, 700)
    time.sleep(0.7)
    print(AK.setPitchRangeMoving((15, 0, 15), -30, -90, 0, 2000))
    time.sleep(2)
    print(AK.setPitchRangeMoving((0, 15, 15), -30, -90, 0, 2000))
    time.sleep(2)
    setBusServoPulse(1, 50, 500)
    time.sleep(0.5)
    
    
    
    #print(AK.setPitchRangeMoving((-4.8, 15, 1.5), 0, -90, 0, 2000))
