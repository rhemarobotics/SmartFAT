#!/usr/bin/env python3
# encoding:utf-8
import cv2
import sys
sys.path.append('/home/pi/RhemaRobotics/')
import math
import numpy as np
from CameraCalibration.CalibrationConfig import *

#相機原點到手臂原點距離(cm)
image_x_distance = 14.075
image_y_distance = 6.2

#相機內外參數.
param_data = np.load(map_param_path + '.npz')
map_param_ = param_data['map_param']

#把數值作線性轉換
def leMap(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

#把相機座標轉成手臂座標.
#Ex: (x, y, size) = (camera position, image resolution)
def convertCoordinate(x, y, size):
    x = leMap(x, 0, size[0], 0, 640)
    x = -1 * (x - 320)
    y_ = round(x * map_param_ + image_center_distance, 2)
    y = leMap(y, 0, size[1], 0, 480)
    y = 240 - y
    x_ = round(y * map_param_, 2)
    return x_, y_

#把物理世界的長度轉成畫面的Pixel值.
#(length, image resolution)
#Ex:(10, (640, 320))
def world2pixel(l, size):
    l_ = round(l/map_param_, 2)
    l_ = leMap(l_, 0, 640, 0, size[0])
    return l_

#取得畫面中物體的ROI區域.
def getROI(box):
    x_min = min(box[0, 0], box[1, 0], box[2, 0], box[3, 0])
    x_max = max(box[0, 0], box[1, 0], box[2, 0], box[3, 0])
    y_min = min(box[0, 1], box[1, 1], box[2, 1], box[3, 1])
    y_max = max(box[0, 1], box[1, 1], box[2, 1], box[3, 1])
    return (x_min, x_max, y_min, y_max)

#把畫面轉成黑色,除了ROI區域.
def getMaskROI(frame, roi, size):
    x_min, x_max, y_min, y_max = roi
    x_min -= 10
    x_max += 10
    y_min -= 10
    y_max += 10
    
    if x_min < 0:
        x_min = 0
    if x_max > size[0]:
        x_max = size[0]
    if y_min < 0:
        y_min = 0
    if y_max > size[1]:
        y_max = size[1]

    black_img = np.zeros([size[1], size[0]], dtype=np.uint8)
    black_img = cv2.cvtColor(black_img, cv2.COLOR_GRAY2RGB)
    black_img[y_min:y_max, x_min:x_max] = frame[y_min:y_max, x_min:x_max]
    
    return black_img

#計算木塊中心座標位置
def getCenter(rect, roi, size, square_length):
    x_min, x_max, y_min, y_max = roi
    if rect[0][0] >= size[0]/2:
        x = x_max 
    else:
        x = x_min
    if rect[0][1] >= size[1]/2:
        y = y_max
    else:
        y = y_min

    square_l = square_length/math.cos(math.pi/4)
    square_l = world2pixel(square_l, size)

    dx = abs(math.cos(math.radians(45 - abs(rect[2]))))
    dy = abs(math.sin(math.radians(45 + abs(rect[2]))))
    if rect[0][0] >= size[0] / 2:
        x = round(x - (square_l/2) * dx, 2)
    else:
        x = round(x + (square_l/2) * dx, 2)
    if rect[0][1] >= size[1] / 2:
        y = round(y - (square_l/2) * dy, 2)
    else:
        y = round(y + (square_l/2) * dy, 2)

    return  x, y

# 計算手臂旋轉角度
# 参数：手臂末端位置座標, 木塊旋轉角
def getAngle(x, y, angle):
    theta6 = round(math.degrees(math.atan2(abs(x), abs(y))), 1)
    angle = abs(angle)
    
    if x < 0:
        if y < 0:
            angle1 = -(90 + theta6 - angle)
        else:
            angle1 = theta6 - angle
    else:
        if y < 0:
            angle1 = theta6 + angle
        else:
            angle1 = 90 - theta6 - angle

    if angle1 > 0:
        angle2 = angle1 - 90
    else:
        angle2 = angle1 + 90

    if abs(angle1) < abs(angle2):
        servo_angle = int(500 + round(angle1 * 1000 / 240))
    else:
        servo_angle = int(500 + round(angle2 * 1000 / 240))
    return servo_angle
