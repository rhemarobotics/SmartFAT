#!/usr/bin/env python3
import os
import sys
from time import time, sleep
import RPi.GPIO as GPIO


if sys.version_info.major == 2:
    print('Please run this program with python3!')
    sys.exit(0)

class Sonar:
    __units = {"mm":0, "cm":1}
    __dist_reg = 0
    #  set GPIO Pin
    Trigger_Pin = 24
    Echo_Pin = 22
    
    def __init__(self):
        # Pin Configuration
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.Trigger_Pin, GPIO.OUT)
        GPIO.setup(self.Echo_Pin, GPIO.IN)

    def __getattr(self, attr):
        if attr in self.__units:
            return self.__units[attr]
        if attr == "Distance":
            return self.getDistance()
        else:
            raise AttributeError('Unknow attribute : %s'%attr)

    # 获取距离, 单位mm
    def getDistance(self):
        dist = 99999
        
        # Check distance from the pulse duration
        self.trigger()
        
        StartTime = time()
        StopTime = time()
     
        # save StartTime
        while GPIO.input(self.Echo_Pin) == 0:
            StartTime = time()
     
        # save time of arrival
        while GPIO.input(self.Echo_Pin) == 1:
            StopTime = time()
     
        # time difference between start and arrival
        TimeElapsed = StopTime - StartTime

        # multiply with the sonic speed (34300 cm/s) and divide by 2
        dist = (TimeElapsed * 34300) / 2        
        
        if dist > 5000:
            dist = 5000
        return dist

    def trigger(self):
        # set Trigger_Pin to HIGH
        GPIO.output(self.Trigger_Pin, True)
        # set Trigger_Pin after 0.01ms to LOW
        sleep(0.00001)
        GPIO.output(self.Trigger_Pin, False)

if __name__ == '__main__':
    s = Sonar()

    while True:
        sleep(1)
        print(s.getDistance())