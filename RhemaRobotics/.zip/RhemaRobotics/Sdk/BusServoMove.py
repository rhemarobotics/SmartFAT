import time
import Board

print('''
**********************************************************
******** 功能:幻尔科技树莓派扩展板，串口舵机控制例程 *************
**********************************************************
Usage:
    sudo python3 BusServoMove.py
----------------------------------------------------------
Tips:
    按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！
----------------------------------------------------------
''')
'''
print(Board.getBusServoPulse(1))
print(Board.getBusServoPulse(2))
print(Board.getBusServoPulse(3))
print(Board.getBusServoPulse(4))
print(Board.getBusServoPulse(5))
print(Board.getBusServoPulse(6))
'''

#Board.setBusServoID(1, 6)
#print(Board.getBusServoID())

#print(Board.getBusServoDeviation(1))
#print(Board.getBusServoAngleLimit(1))
#print(Board.getBusServoVinLimit(1))
#print(Board.getBusServoTemp(1))

#print(Board.getBusServoDeviation(1))

while True:
    '''
    Board.setBusServoPulse(1, 500, 500)
    time.sleep(0.5)

    Board.setBusServoPulse(2, 500, 500)
    time.sleep(0.5)

    Board.setBusServoPulse(3, 500, 500)
    time.sleep(0.5)

    Board.setBusServoPulse(4, 490, 490)
    time.sleep(0.49)

    Board.setBusServoPulse(5, 510, 510)
    time.sleep(0.51)
    '''
    Board.setBusServoPulse(6, 500, 500)
    time.sleep(0.50)

    '''
    # 参数：参数1：舵机id; 参数2：位置; 参数3：运行时间
    Board.setBusServoPulse(2, 500, 500) # 2号舵机转到500位置，用时500ms
    time.sleep(0.5) # 延时时间和运行时间相同
    
    Board.setBusServoPulse(2, 200, 500) #舵机的转动范围0-240度，对应的脉宽为0-1000,即参数2的范围为0-1000
    time.sleep(0.5)
    
    Board.setBusServoPulse(2, 500, 200)
    time.sleep(0.2)
    
    Board.setBusServoPulse(2, 200, 200)
    time.sleep(0.2)
    
    Board.setBusServoPulse(2, 500, 500)  
    Board.setBusServoPulse(3, 300, 500)
    time.sleep(0.5)
    
    Board.setBusServoPulse(2, 200, 500)  
    Board.setBusServoPulse(3, 500, 500)
    time.sleep(0.5)    
    '''
    
    '''
    Board.stopBusServo(0)   #stop all servo
    time.sleep(0.5)    

    Board.unloadBusServo(1) #torque off
    time.sleep(0.5)
    Board.unloadBusServo(2)
    time.sleep(0.5)
    Board.unloadBusServo(3)
    time.sleep(0.5)
    Board.unloadBusServo(4)
    time.sleep(0.5)
    Board.unloadBusServo(5)
    time.sleep(0.5)
    Board.unloadBusServo(6)
    time.sleep(0.5)
    '''