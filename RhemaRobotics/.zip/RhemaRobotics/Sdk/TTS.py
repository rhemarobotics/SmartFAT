'''-------------------------------------------------
RPi Text-To-Speech(TTS)
語音合成模組使用範例：執行後,會發出"你好"的聲音
----------------------------------------------------
'''
#!/usr/bin/env python3
# coding=utf8
import time
import smbus


class TTS:

    address = 0x30
    bus = None

    def __init__(self, bus=1):
        self.bus = smbus.SMBus(bus)
    
    def WireReadTTSDataByte(self):
        try:
            val = self.bus.read_byte(self.address)
        except:
            return False
        return True
    
    def TTSModuleSpeak(self, sign, words):
        head = [0xFD,0x00,0x00,0x01,0x00]             #文本播放命令
        wordslist = words.encode("gb2312")            #文本編碼格式GB2312
        signdata = sign.encode("gb2312")    
        length = len(signdata) + len(wordslist) + 2
        head[1] = length >> 8
        head[2] = length
        head.extend(list(signdata))
        head.extend(list(wordslist))       
        try:
            self.bus.write_i2c_block_data(self.address, 0, head) #向從機發送數據
        except:
            pass
        time.sleep(0.05)
        
if __name__ == '__main__':
    v = TTS()
    #[h0]設置單字發音方式，0為自動判斷單字發音方式，1為字母發音方式，2為單字發音方式
    #[v10]設置音量，音量範圍為0-10,10為最大音量
    #[m53]選擇聲音，3是女聲1，51是男聲1，52是男聲2，53是女聲2
    v.TTSModuleSpeak("[h0][v10][m52]","你好")
    #注意括號里的單字長度不能超過32,如果超過了請分多次來說
    time.sleep(1) #延遲時間,等待說話完成
