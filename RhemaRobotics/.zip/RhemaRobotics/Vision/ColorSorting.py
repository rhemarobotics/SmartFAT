#!/usr/bin/env python3
# encoding:utf-8
import sys
sys.path.append('/home/pi/RhemaRobotics/')
import cv2
import numpy as np
from Package import opencvfunc, Camera
from CameraCalibration.CalibrationConfig import *

if sys.version_info.major == 2:
    print('Please run this program with python3!')
    sys.exit(0)

__target_color = ''

# set target color
def setTargetColor(target_color):
    global __target_color # declare it is a global variable.
    __target_color = target_color
    return True, ()

def run(img):
    rect = None
    size = (640, 480)
    
    # draw a cross line in the middle of frame.
    opencvfunc.drawCrossLine(img)
    # image processing.
    img_resize = cv2.resize(img.copy(), size, interpolation=cv2.INTER_NEAREST)
    img_gb = cv2.GaussianBlur(img_resize, (11, 11), 11)
    img_lab = cv2.cvtColor(img_gb, cv2.COLOR_BGR2LAB)
    # find target color.
    imgcanny = opencvfunc.filterColour(img_lab, __target_color)
    # find its contour
    imgproc, rect = opencvfunc.getContours(imgcanny, img_resize, rect)
    if not rect is None:
        # get Roi
        box = np.int0(cv2.boxPoints(rect))
        # draw a text
        cv2.putText(imgproc, '(' + __target_color + ')', (min(box[0, 0], box[2, 0]), box[2, 1] - 10),
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, opencvfunc.range_rgb['green'], 1)
    else:
        print('cannot find the target.')
    return imgproc

# Demo and press 'ESC' to stop.
if __name__ == '__main__':
    #setTargetColor('red', 'green', 'blue')
    setTargetColor('red')
    my_camera = Camera.Camera()
    my_camera.camera_open()
    #main loop
    while True:
        img = my_camera.frame
        if img is not None:
            frame = img.copy()
            Frame = run(frame)
            cv2.imshow('Frame', Frame)
            key = cv2.waitKey(1)
            if key == 27:
                break
    #end loop
    my_camera.camera_close()
    cv2.destroyAllWindows()
